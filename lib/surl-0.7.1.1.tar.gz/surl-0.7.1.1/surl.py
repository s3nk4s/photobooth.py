#!/usr/bin/python
""" surl wrapper """

import sys
import surl.surl as surl

if __name__ == '__main__':
    surl.main() # Execute surl module main function
