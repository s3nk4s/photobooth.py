=========
 surl
=========

-----------------------------------------------------
a URL shortening application, supports various sites
-----------------------------------------------------

:Author:
    Savvas Radevic <vicedar@gmail.com>,
    Ahmed El-Mahdawy <aa.mahdawy.10@gmail.com>
:Date:   2011-01-06
:Copyright:
    Copyright © 2009-2011 Savvas Radevic <vicedar@gmail.com>,
    Copyright © 2009-2010 Ahmed El-Mahdawy <aa.mahdawy.10@gmail.com>
:Version: 0.7
:Manual section: 1
:Manual group: text processing

.. Created using rst2man (python-docutils)

SYNOPSIS
========

surl [OPTION]

Modes: stdin or -f (default: stdin)

DESCRIPTION
===========

surl is a command line application that can transform links and shorten them.

The idea is to input a huge amount of text and/or links.

The input can be in two modes:

    * stdin (standard input or piped command, ``default``)
    * read input from a text file (using the -f option)

OPTIONS
=======

-h, --help                  This help message
-v, --version               Prints version info
-c, --url <url>             URL to shorten
-a, --api-key <key>         Use an API key
-f, --file <filename>       Read input from filename
-i, --in-place              Save changes to file directly (Requires: -f)
-l, --links-only            Output only a list of links (old_url => shortened_url)
-o, --output <filename>     Output to file
-p, --password <password>   Your password
-q, --quiet                 Suppress any extra messages
-t, --title <title>         Title (short custom name/alias) for the url
-u, --username <username>   Your username
-s, --service <service>     The URL shortening service to use (Default: tinyurl.com)
-r, --script <path>         The surlscript to execute

SUPPORTED SERVICES
==================
surl supports a vast range of url shortening services.

You can view the full list by typing: ``surl --help``

EXAMPLES
========
* ``echo 'http://google.co.uk' | surl -a myapikey123 -u example -s bit.ly``
* ``echo 'http://www.google.com' | surl -s tr.im``
* ``surl -c http://www.google.com -s tr.im``
* ``surl -f example.txt -i -s tr.im``

BUGS
====
Should you find any bugs, report them at: `https://bugs.launchpad.net/surl`


